package com.example.leonardo.projetologin

import android.app.Activity
import android.arch.persistence.room.Room
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.cadastro_usuario.*
import java.io.File
import java.util.jar.Manifest

class CadastroUsuario : AppCompatActivity() {

    private var PERMISSION_REQUEST_CODE = 200
    private var TAKE_PHOTO_REQUEST = 101
    var mCurrentPhotoPath : String =  ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cadastro_usuario)
        supportActionBar?.title = "Cadastro de Usuário"


        val db = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "room-database"
        ).allowMainThreadQueries().build()



        imageView_imagemUsuario.setOnClickListener{

            Toast.makeText(this@CadastroUsuario,"Teste Foto",Toast.LENGTH_LONG).show()
            validarPermissoes()

        }



        button_cadastrar_usuario.setOnClickListener {


            if (editText_email_cadastro.text.toString().trim().isNullOrEmpty()) {
                editText_email_cadastro?.error = "email obrigatório."
            } else {
               if(editText_senha_cadastro.text.toString().trim().isNullOrEmpty()){
                   editText_senha_cadastro?.error = "senha obrigatória."
               } else{
                   if(editText_confirmacao_cadastro.text.toString().trim().isNullOrEmpty()) {
                       editText_confirmacao_cadastro?.error = "confirmacao obrigatória."
                   }else{

                       if(!editText_senha_cadastro.text.toString().equals(editText_confirmacao_cadastro.text.toString())){
                           Toast.makeText(this@CadastroUsuario, "Senhas diferentes. Redigite.",
                                   Toast.LENGTH_LONG).show()
                           editText_senha_cadastro.requestFocus();
                       }else{
                           val usuario = Usuario(email = editText_email_cadastro.text.toString(),
                                   senha = editText_senha_cadastro.text.toString())

                           // val produto = Produto(nome = "produto test1", preco = "123", descricao = "test description", imagem = "")

                           db.romDao().insertUsuario(usuario)
                           Toast.makeText(this@CadastroUsuario, "Usuario cadastrado com sucesso!", Toast.LENGTH_LONG).show()
                           val intent = Intent(this@CadastroUsuario,Login::class.java)
                           startActivity(intent)
                           finish()
                       }

                   }
               }
            }


        }



    }

    fun validarPermissoes(){

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this@CadastroUsuario, "Permissão não concedida para 'Camera'", Toast.LENGTH_LONG).show()

            ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.CAMERA),PERMISSION_REQUEST_CODE )


        }else{
            Toast.makeText(this@CadastroUsuario, "Permissão concedida para 'Camera'", Toast.LENGTH_LONG).show()
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this@CadastroUsuario, "Permissão não concedida \n para 'Write External Storage ", Toast.LENGTH_LONG).show()

                ActivityCompat.requestPermissions(this, arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE),20 )

            }else{
                Toast.makeText(this@CadastroUsuario, "Permissão concedida \n para 'Write External Storage ", Toast.LENGTH_LONG).show()
                abrirCamera()
            }

        }
        //abrirCamera()
    }

    fun abrirCamera(){
        Toast.makeText(this@CadastroUsuario, "Abrindo Camera...", Toast.LENGTH_LONG).show()

        val values = ContentValues(1)
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpg")
        val fileUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if(intent.resolveActivity(packageManager) != null){
            mCurrentPhotoPath = fileUri.toString()
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fileUri)
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            startActivityForResult(intent, TAKE_PHOTO_REQUEST)
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK && requestCode == TAKE_PHOTO_REQUEST){
            processaFotoCapturada()
        }else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    fun processaFotoCapturada(){
        val cursor =  contentResolver.query(Uri.parse(mCurrentPhotoPath),
                Array(1){android.provider.MediaStore.Images.ImageColumns.DATA},
                null,null,null)
        cursor.moveToFirst()
        val photoPath = cursor.getString(0)
        cursor.close()
        val file = File(photoPath)
        val uri = Uri.fromFile(file)

        imageView_imagemUsuario.setImageBitmap(decodificaBitmatDeArquivo(file.absolutePath,250,250))

    }

    fun decodificaBitmatDeArquivo(path: String, reqWidth: Int, reqHeight: Int): Bitmap{

        var options : BitmapFactory.Options = BitmapFactory.Options()
        options.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, options)

        var height:Int = options.outHeight
        var width: Int = options.outWidth

        options.inPreferredConfig = Bitmap.Config.RGB_565
        var inSampleSize = 1

        if(height > reqHeight){
            inSampleSize = (Math.round(height as Float)/(reqHeight as Float)) as Int
        }

        var expectedWidth : Int = width /inSampleSize

        if(expectedWidth > reqWidth){
            inSampleSize = (Math.round(width as Float)/(reqWidth as Float)) as Int
        }

        options.inSampleSize = inSampleSize

        options.inJustDecodeBounds = false

        return BitmapFactory.decodeFile(path,options)
    }

}

